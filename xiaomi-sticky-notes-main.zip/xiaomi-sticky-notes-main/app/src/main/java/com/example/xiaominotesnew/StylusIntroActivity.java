package com.example.xiaominotesnew;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import net.micode.notes.R;
import net.micode.notes.ui.NotesListActivity;

public class StylusIntroActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String PREFS_NAME = "stylus_intro";
    private static final String PREF_INTRO_SEEN = "intro_seen";

    private TextView mDescriptionView;
    private TextView mInputHintView;

    private View mWriteChip;
    private View mDeleteChip;
    private View mSelectChip;

    private View mMicTool;
    private View mDeleteTool;
    private View mBackTool;
    private View mFaceTool;
    private View mMenuTool;

    private enum Mode {
        WRITE(R.string.stylus_intro_description_write, R.string.stylus_intro_input_write),
        DELETE(R.string.stylus_intro_description_delete, R.string.stylus_intro_input_delete),
        SELECT(R.string.stylus_intro_description_select, R.string.stylus_intro_input_select);

        @StringRes
        final int descriptionRes;
        @StringRes
        final int inputHintRes;

        Mode(int descriptionRes, int inputHintRes) {
            this.descriptionRes = descriptionRes;
            this.inputHintRes = inputHintRes;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (hasSeenIntro()) {
            openNotesList();
            return;
        }

        setContentView(R.layout.activity_stylus_intro);
        bindViews();
        setMode(Mode.WRITE);
    }

    private void bindViews() {
        mDescriptionView = findViewById(R.id.stylus_description);
        mInputHintView = findViewById(R.id.stylus_input_hint);

        mWriteChip = findViewById(R.id.tab_write);
        mDeleteChip = findViewById(R.id.tab_delete);
        mSelectChip = findViewById(R.id.tab_select);

        mMicTool = findViewById(R.id.tool_mic);
        mDeleteTool = findViewById(R.id.tool_delete);
        mBackTool = findViewById(R.id.tool_back);
        mFaceTool = findViewById(R.id.tool_face);
        mMenuTool = findViewById(R.id.tool_menu);

        mWriteChip.setOnClickListener(this);
        mDeleteChip.setOnClickListener(this);
        mSelectChip.setOnClickListener(this);
        mMicTool.setOnClickListener(this);
        mDeleteTool.setOnClickListener(this);
        mBackTool.setOnClickListener(this);
        mFaceTool.setOnClickListener(this);
        mMenuTool.setOnClickListener(this);

        findViewById(R.id.button_reset).setOnClickListener(v -> setMode(Mode.WRITE));
        findViewById(R.id.button_cancel).setOnClickListener(v -> completeIntro());
        findViewById(R.id.button_next).setOnClickListener(v -> completeIntro());
    }

    @Override
    public void onClick(View view) {
        int viewId = view.getId();
        if (viewId == R.id.tab_write || viewId == R.id.tool_mic || viewId == R.id.tool_back) {
            setMode(Mode.WRITE);
        } else if (viewId == R.id.tab_delete || viewId == R.id.tool_delete) {
            setMode(Mode.DELETE);
        } else if (viewId == R.id.tab_select || viewId == R.id.tool_face || viewId == R.id.tool_menu) {
            setMode(Mode.SELECT);
        }
    }

    private void setMode(Mode mode) {
        mWriteChip.setSelected(mode == Mode.WRITE);
        mDeleteChip.setSelected(mode == Mode.DELETE);
        mSelectChip.setSelected(mode == Mode.SELECT);

        mMicTool.setSelected(mode == Mode.WRITE);
        mDeleteTool.setSelected(mode == Mode.DELETE);
        mBackTool.setSelected(false);
        mFaceTool.setSelected(mode == Mode.SELECT);
        mMenuTool.setSelected(false);

        mDescriptionView.setText(mode.descriptionRes);
        mInputHintView.setText(mode.inputHintRes);
    }

    private void completeIntro() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        preferences.edit().putBoolean(PREF_INTRO_SEEN, true).apply();
        openNotesList();
    }

    private boolean hasSeenIntro() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return preferences.getBoolean(PREF_INTRO_SEEN, false);
    }

    private void openNotesList() {
        startActivity(new Intent(this, NotesListActivity.class));
        finish();
    }
}
