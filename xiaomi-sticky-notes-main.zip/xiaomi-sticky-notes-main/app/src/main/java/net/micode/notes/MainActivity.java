package net.micode.notes;

import android.app.Activity;

public class MainActivity extends Activity {
}
